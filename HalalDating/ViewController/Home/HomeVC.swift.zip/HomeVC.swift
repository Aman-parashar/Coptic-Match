//
//  HomeVC.swift
//  HalalDating
//
//  Created by Maulik Vora on 27/11/21.
//

import UIKit
import Koloda
import Cartography
import Alamofire
import CoreLocation
import Quickblox
import QuickbloxWebRTC
import GoogleMaps


class HomeVC: UIViewController {
    //MARK: - @IBOutlet
    @IBOutlet weak var collview: UICollectionView!
    @IBOutlet weak var viewHeader: UIView!
    
    @IBOutlet weak var lblNoResultFound: UILabel!
    
    @IBOutlet weak var btnVisibility: UIButton!
    
    @IBOutlet weak var btnExplore: UIButton!
    @IBOutlet weak var btnRelationship: UIButton!
    @IBOutlet weak var btnMarriage: UIButton!
    @IBOutlet weak var btnOnline: UIButton!
    
    @IBOutlet weak var lblLogosHeader: UILabel!
    
    @IBOutlet weak var kolodaView: KolodaView!
    
    @IBOutlet weak var headerBGView: UIView!
    @IBOutlet weak var btnFilter: UIButton!
    
    
    //MARK: - Veriable
    var loadCardsFromXib = true
    var arrUserList:[UserData] = []
    var arrFlag:[Int] = []
    var selectIndexForDetailProfile = 0
    var arr:[[String:Any]] = []
    var isFromHomeDetailsScreen = false
    
    var intCountArr = 0
    var currentPage = 1
    var last_page = 0
    
    //--
    var latitude = ""
    var longitude = ""
    var centerMapCoordinate:CLLocationCoordinate2D!
    let locationManager = CLLocationManager()
    
    //audio call
    var counter:TimeInterval = 0
    var timer = Timer()
    let dateFormatter : DateComponentsFormatter = {
        let formatter = DateComponentsFormatter()
        formatter.allowedUnits = [.hour,.minute, .second]
        formatter.zeroFormattingBehavior = .pad
        return formatter
    }()
    //let audioSession = QBRTCAudioSession.instance()
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    //var arrDialogs:[QBChatDialog]?
    
    let refreshControl = UIRefreshControl()
    
    //MARK: - func
    override func viewDidLoad() {
        super.viewDidLoad()
        //
        setupUI()
        sendOnlineUserStatusAPI()
        initCurrentLocation()
        
        //audio call
        //EDIT
        /*QBRTCClient.instance().add(self)
         
         
         //make connection to do chat and call
         let currentUser = QBSession.current.currentUser//QBUUser()
         
         if currentUser != nil {
         QBChat.instance.connect(withUserID: currentUser!.id, password: "quickblox", completion: { (error) in
         print(error)
         })
         } else {
         AppHelper.returnTopNavigationController().view.makeToast("Current user is not found")
         }
         
         self.getAllDialogs()*/
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        setLanguageUI()
        setTopView()
        self.tabBarController?.tabBar.isHidden = false
        self.navigationController?.navigationBar.isHidden = true
        
        //
        if isFromHomeDetailsScreen == false {
            reloadData()
            
            //--
            apiCall_checkSubscription()
        } else {
            isFromHomeDetailsScreen = false
        }
        
        
        //
        getProfileStatusAPI()
        
        //
        DispatchQueue.global(qos: .userInitiated).async {
//            self.getNotificationsAPI()
//            self.getChatCount()
            self.apiCall_likedUserList()
        }
        
        self.timer = Timer.scheduledTimer(withTimeInterval: 5, repeats: true, block: { _ in
            self.getChatCount()
        })

//        NotificationCenter.default.addObserver(self, selector: #selector(self.refreshBadge(notification:)), name: Notification.Name("NotificationIdentifier_RefreshBadge"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.refreshBadge(notification:)), name: Notification.Name("NotificationIdentifier_RefreshChatBadge"), object: nil)
        
        
    }
    override func viewWillDisappear(_ animated: Bool) {
        
//        NotificationCenter.default.removeObserver(self, name: Notification.Name("NotificationIdentifier_RefreshBadge"), object: nil)
//        NotificationCenter.default.removeObserver(self, name: Notification.Name("NotificationIdentifier_RefreshChatBadge"), object: nil)
        timer.invalidate()
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
    }
    
    func setLanguageUI() {
        
        if Helper.shared.strLanguage == "ar"  {
            
            viewHeader.semanticContentAttribute = .forceRightToLeft
            //stackviewFilter.semanticContentAttribute = .forceRightToLeft
            
        }
        
    }
    
    func setupUI() {
        
//        collview.dataSource = self
//        collview.delegate = self
        
        collview.register(UINib(nibName: "HomeCollCell", bundle: nil), forCellWithReuseIdentifier: "HomeCollCell")
        
        self.kolodaView.dataSource = self
        self.kolodaView.delegate   = self

        //
        refreshControl.addTarget(self, action: #selector(didPullToRefresh(_:)), for: .valueChanged)
        collview.alwaysBounceVertical = true
        collview.refreshControl = refreshControl
        
        //
        showLocationSettingsAlert()
        
        //
        ReceiptValidationIAP.shared.receiptValidation()
    }
    @objc func refreshBadge(notification: Notification) {
        
        getChatCount()
//        setChatTabNotificationBadge()
    }
    
    func initCurrentLocation() {
        // Ask for Authorisation from the User.
        self.locationManager.requestAlwaysAuthorization()
        
        // For use in foreground
        self.locationManager.requestWhenInUseAuthorization()
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
        }
    }
    
    func showLocationSettingsAlert() {
        
        let userModel = Login_LocalDB.getLoginUserModel()
        if userModel.data?.lat == "" {
            
            if !hasLocationPermission() {
                checkIfLocationServicesEnabled()
            } else {
                //API call made in locationManager method to update location
            }
            
        } else if userModel.data?.your_zodiac == "" {
            showZodiacAlert()
        }
    }
    
    func checkIfLocationServicesEnabled() {
        
        if !hasLocationPermission() {
            let alertController = UIAlertController(title: "Set your location services", message: "We use your location to show you users in your area.", preferredStyle: .alert)
            
            let okAction = UIAlertAction(title: "Set location services", style: .default, handler: {(cAlertAction) in
                //Redirect to Settings app
                UIApplication.shared.open(URL(string:UIApplication.openSettingsURLString)!)
                
                //closes app so that viewdidload called again because alert dismiss on btn tap and doesnt appear again
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                    UIApplication.shared.perform(#selector(NSXPCConnection.suspend))
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        exit(0)
                    }
                }
            })
            
            //            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
            //            alertController.addAction(cancelAction)
            
            alertController.addAction(okAction)
            
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    func hasLocationPermission() -> Bool {
        var hasPermission = false
        let manager = CLLocationManager()
        
        if CLLocationManager.locationServicesEnabled() {
            switch manager.authorizationStatus {
            case .notDetermined, .restricted, .denied:
                hasPermission = false
            case .authorizedAlways, .authorizedWhenInUse:
                hasPermission = true
            @unknown default:
                break
            }
        } else {
            hasPermission = false
        }
        
        return hasPermission
    }
    
    func showZodiacAlert() {
        
        let alertController = UIAlertController(title: kAlertTitle, message: "Please add zodiac sign in Edit Profile", preferredStyle: .alert)
        
        //        let okAction = UIAlertAction(title: "Okay", style: .default, handler: {(cAlertAction) in
        //
        //
        //            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
        //
        //            }
        //        })
        
        let cancelAction = UIAlertAction(title: "OK", style: .cancel)
        alertController.addAction(cancelAction)
        
        //alertController.addAction(okAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    @objc func didPullToRefresh(_ sender: Any) {
        // Do you your api calls in here, and then asynchronously remember to stop the
        // refreshing when you've got a result (either positive or negative)
        self.collview!.refreshControl?.beginRefreshing()
        //
        reloadData()
        refreshControl.endRefreshing()
    }
    
    func reloadData() {
        
        arrFlag.removeAll()
        arrUserList.removeAll()
        intCountArr = 0
        currentPage = 1
        apiCall_userList(page: 1)
    }
    
    func setTopView() {
        
        if UserDefaults.standard.object(forKey: "status_filter") == nil && UserDefaults.standard.object(forKey: "looking_for_filter") == nil {
            
            //
            btnExplore.setTitleColor(UIColor.black, for: .normal)
            btnRelationship.setTitleColor(UIColor(named: "AppGray"), for: .normal)
            btnMarriage.setTitleColor(UIColor(named: "AppGray"), for: .normal)
            btnOnline.setTitleColor(UIColor(named: "AppGray"), for: .normal)
        } else {
            
            //
            let str_looking_for_filter = UserDefaults.standard.object(forKey: "looking_for_filter") as? String
            let str_status_filter = UserDefaults.standard.object(forKey: "status_filter") as? String
            
            if str_looking_for_filter != nil {
                if str_looking_for_filter == "Marriage" {
                    
                    btnExplore.setTitleColor(UIColor(named: "AppGray"), for: .normal)
                    btnMarriage.setTitleColor(UIColor.black, for: .normal)
                    btnRelationship.setTitleColor(UIColor(named: "AppGray"), for: .normal)
                    btnOnline.setTitleColor(UIColor(named: "AppGray"), for: .normal)
                } else if str_looking_for_filter == "Relationship" {
                    
                    btnExplore.setTitleColor(UIColor(named: "AppGray"), for: .normal)
                    btnMarriage.setTitleColor(UIColor(named: "AppGray"), for: .normal)
                    btnRelationship.setTitleColor(UIColor.black, for: .normal)
                    btnOnline.setTitleColor(UIColor(named: "AppGray"), for: .normal)
                } else {
                    
                    btnExplore.setTitleColor(UIColor(named: "AppGray"), for: .normal)
                    btnMarriage.setTitleColor(UIColor(named: "AppGray"), for: .normal)
                    btnRelationship.setTitleColor(UIColor(named: "AppGray"), for: .normal)
                    btnOnline.setTitleColor(UIColor(named: "AppGray"), for: .normal)
                }
            } else if str_status_filter != nil {
                
                btnExplore.setTitleColor(UIColor(named: "AppGray"), for: .normal)
                btnRelationship.setTitleColor(UIColor(named: "AppGray"), for: .normal)
                btnMarriage.setTitleColor(UIColor(named: "AppGray"), for: .normal)
                btnOnline.setTitleColor(UIColor.black, for: .normal)
            }
            
        }
        
    }
    
    //MARK: - Function
    //audio call
    //EDIT
    /*func openAudioCallView(img:String, name:String) {
     
     let customView = Bundle.main.loadNibNamed("AudioCallView", owner: self)?.first as? AudioCallView
     customView?.tag = 5001
     customView?.frame = view.bounds
     if HelperAudioCall.shared.isCallReceived {
     customView?.btnAcceptCall.isHidden = false
     customView?.btnRejectCall.isHidden = false
     customView?.btnHungUp.isHidden = true
     } else {
     customView?.btnAcceptCall.isHidden = true
     customView?.btnRejectCall.isHidden = false
     customView?.btnHungUp.isHidden = true
     }
     
     customView?.lblName.text = name
     customView?.imgUser.sd_setImage(with: URL(string: img))
     
     customView?.btnRejectCall.addTarget(self, action: #selector(btnRejectCall), for: .touchUpInside)
     customView?.btnAcceptCall.addTarget(self, action: #selector(btnAcceptCall), for: .touchUpInside)
     customView?.btnHungUp.addTarget(self, action: #selector(btnHungUpCall), for: .touchUpInside)
     customView?.btnMute.addTarget(self, action: #selector(btnMuteCall), for: .touchUpInside)
     customView?.btnSpeaker.addTarget(self, action: #selector(btnSpeakerCall), for: .touchUpInside)
     //self.view.addSubview(customView!)
     
     
     //        appDelegate.window?.rootViewController = obj
     appDelegate.window?.addSubview(customView!)
     
     }
     
     @objc func btnRejectCall() {
     
     HelperAudioCall.shared.stopSound()
     
     // userInfo - the custom user information dictionary for the reject call. May be nil.
     let userInfo = ["key":"value"] // optional
     HelperAudioCall.shared.session?.rejectCall(userInfo)
     
     // and release session instance
     HelperAudioCall.shared.session = nil
     appDelegate.window?.viewWithTag(5001)?.removeFromSuperview()
     cancelTimer()
     }
     @objc func btnAcceptCall() {
     (appDelegate.window?.viewWithTag(5001) as? AudioCallView)?.lblTimer.isHidden = false
     HelperAudioCall.shared.stopSound()
     (appDelegate.window?.viewWithTag(5001) as? AudioCallView)?.btnAcceptCall.isHidden = true
     (appDelegate.window?.viewWithTag(5001) as? AudioCallView)?.btnRejectCall.isHidden = true
     (appDelegate.window?.viewWithTag(5001) as? AudioCallView)?.btnHungUp.isHidden = false
     (appDelegate.window?.viewWithTag(5001) as? AudioCallView)?.btnMute.isHidden = false
     (appDelegate.window?.viewWithTag(5001) as? AudioCallView)?.btnSpeaker.isHidden = false
     
     // userInfo - the custom user information dictionary for the accept call. May be nil.
     let userInfo = ["key":"value"] // optional
     HelperAudioCall.shared.session?.acceptCall(userInfo)
     startTimer()
     }
     @objc func btnHungUpCall() {
     
     // userInfo - the custom user information dictionary for the reject call. May be nil.
     let userInfo = ["key":"value"] // optional
     HelperAudioCall.shared.session?.hangUp(userInfo)
     
     // and release session instance
     HelperAudioCall.shared.session = nil
     appDelegate.window?.viewWithTag(5001)?.removeFromSuperview()
     cancelTimer()
     }
     @objc func btnMuteCall() {
     
     
     if HelperAudioCall.shared.session?.localMediaStream.audioTrack.isEnabled == true {
     (appDelegate.window?.viewWithTag(5001) as? AudioCallView)?.btnMute.setImage(#imageLiteral(resourceName: "mic-off"), for: .normal)
     } else {
     (appDelegate.window?.viewWithTag(5001) as? AudioCallView)?.btnMute.setImage(#imageLiteral(resourceName: "mic-on"), for: .normal)
     }
     
     HelperAudioCall.shared.session?.localMediaStream.audioTrack.isEnabled = !(HelperAudioCall.shared.session?.localMediaStream.audioTrack.isEnabled)!
     }
     @objc func btnSpeakerCall() {
     
     if (appDelegate.window?.viewWithTag(5001) as? AudioCallView)?.btnSpeaker.tag == 0 {
     (appDelegate.window?.viewWithTag(5001) as? AudioCallView)?.btnSpeaker.tag = 1
     (appDelegate.window?.viewWithTag(5001) as? AudioCallView)?.btnSpeaker.setImage(#imageLiteral(resourceName: "speaker-on"), for: .normal)
     
     //            let isActive = true
     //            audioSession.setActive(isActive)
     
     let speaker: AVAudioSession.PortOverride = .speaker
     audioSession.overrideOutputAudioPort(speaker)
     
     } else {
     (appDelegate.window?.viewWithTag(5001) as? AudioCallView)?.btnSpeaker.tag = 0
     (appDelegate.window?.viewWithTag(5001) as? AudioCallView)?.btnSpeaker.setImage(#imageLiteral(resourceName: "speaker-off"), for: .normal)
     
     //            let isActive = false
     //            audioSession.setActive(isActive)
     let receiver: AVAudioSession.PortOverride = .none
     audioSession.overrideOutputAudioPort(receiver)
     }
     
     }
     
     func startTimer() {
     counter = 0
     timer.invalidate() // just in case this button is tapped multiple times
     
     // start the timer
     timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(timerAction), userInfo: nil, repeats: true)
     }
     
     // stop timer
     func cancelTimer() {
     timer.invalidate()
     }
     
     @objc func timerAction() {
     counter += 1
     
     if appDelegate.window?.viewWithTag(5001) != nil {
     (appDelegate.window?.viewWithTag(5001) as! AudioCallView).lblTimer.text = dateFormatter.string(from: counter)!
     }
     
     }*/
    //EDIT
    //    func processChat(quickbox_id:String) {
    //
    //        let user = NSNumber(value: QBSession.current.currentUser!.id)
    //        let receiver = NSNumber(value: UInt(Int(quickbox_id)!))
    //
    //        let arr:[NSNumber] = [receiver,user]
    //
    //        let index = arrDialogs?.firstIndex{$0.occupantIDs == arr}
    //
    //        if let _ = index {
    //
    //            //go to chat screen
    //
    //            let vc = OnetoOneChatVC(nibName: "OnetoOneChatVC", bundle: nil)
    //            vc.dictReceiver = arrDialogs?[index!]
    //            self.navigationController?.pushViewController(vc, animated: true)
    //            //print(arrDialogs?[index!])
    //        } else {
    //
    //            let arr2:[NSNumber] = [user,receiver]
    //
    //            let index2 = arrDialogs?.firstIndex{$0.occupantIDs == arr2}
    //
    //            if let _ = index2 {
    //
    //                //go to chat screen
    //                let vc = OnetoOneChatVC(nibName: "OnetoOneChatVC", bundle: nil)
    //                vc.dictReceiver = arrDialogs?[index2!]
    //                self.navigationController?.pushViewController(vc, animated: true)
    //                //print(arrDialogs?[index2!])
    //            } else {
    //
    //                //create
    //                createDialog(userId: UInt(Int(quickbox_id)!))
    //            }
    //        }
    //
    //    }
    
//    func setChatTabNotificationBadge() {
//        
//        if let cnt = UserDefaults.standard.value(forKey: "notiBadgeCount") as? Int {
//            
//            if self.arr != nil && self.arr.count != 0 {
//                
//                if self.arr.count != cnt {
//                    
//                    if let tabItems = self.tabBarController?.tabBar.items {
//                        let tabItem = tabItems[2]
//                        
//                        Helper.shared.getUnreadMsgCount { count in
//                            tabItem.badgeValue = "\((self.arr.count-cnt)+count)"
//                        }
//                    }
//                    
//                } else {
//                    Helper.shared.setUnreadMsgCount(vc: self)
//                }
//            } else {
//                Helper.shared.setUnreadMsgCount(vc: self)
//            }
//        } else {
//            Helper.shared.setUnreadMsgCount(vc: self)
//            UserDefaults.standard.setValue(self.arr.count, forKey: "notiBadgeCount")
//            UserDefaults.standard.synchronize()
//        }
//    }
    
    
    
    //MARK: - ApiCall
    func apiCall_checkSubscription()  {
        if NetworkReachabilityManager()!.isReachable == false
        {
            let alert = UIAlertController(title: internetConnectedTitle.localizableString(lang: Helper.shared.strLanguage), message: internetConnected, preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK".localizableString(lang: Helper.shared.strLanguage), style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else
        {
            //--
            let dicParam:[String:AnyObject] = [:]
            let userModel = Login_LocalDB.getLoginUserModel()
            //AppHelper.showLinearProgress()
            self.view.isUserInteractionEnabled = false
            HttpWrapper.requestWithparamdictParamPostMethodwithHeader(url: a_checkSubscription, dicsParams: dicParam, headers: ["Authorization":userModel.data?.api_token ?? ""], completion: { [self] (response) in
                self.view.isUserInteractionEnabled = true
                AppHelper.hideLinearProgress()
                let dicsResponseFinal = response.replaceNulls(with: "")
                print(dicsResponseFinal as Any)
                
                let checkSubscriptionModel = CheckSubscriptionModel(JSON: dicsResponseFinal as! [String : Any])!
                if checkSubscriptionModel.code == 200{
                    
                    if let checkSubscriptionModel_ = CheckSubscriptionModel(JSON: dicsResponseFinal as! [String : Any])!.toJSONString(){
                        ManageSubscriptionInfo.saveSubscriptionInfo(strData: checkSubscriptionModel_)
                    }
                    
                }else if checkSubscriptionModel.code == 401{
                    AppHelper.Logout(navigationController: self.navigationController!)
                }else{
                    self.view.makeToast(dicsResponseFinal?.object(forKey: "message") as? String ?? "")
                }
            }) { (error) in
                print(error)
                self.view.isUserInteractionEnabled = true
                AppHelper.hideLinearProgress()
            }
        }
    }
    
//    func apiCall_userLikeDislike(like: String, op_user_id: String, customSwipe: String, index:Int) {
//        
//        if NetworkReachabilityManager()!.isReachable == false
//        {
//            let alert = UIAlertController(title: internetConnectedTitle.localizableString(lang: Helper.shared.strLanguage), message: internetConnected, preferredStyle: UIAlertController.Style.alert)
//            alert.addAction(UIAlertAction(title: "OK".localizableString(lang: Helper.shared.strLanguage), style: UIAlertAction.Style.default, handler: nil))
//            self.present(alert, animated: true, completion: nil)
//        }
//        else
//        {
//            //--
//            let dicParam:[String:AnyObject] = ["op_user_id":op_user_id as AnyObject,
//                                               "flag":like as AnyObject,
//                                               "plan_purchased":ManageSubscriptionInfo.getSubscriptionModel().data?.is_buy_valid_subscription_new as AnyObject]
//            let userModel = Login_LocalDB.getLoginUserModel()
//            //AppHelper.showLinearProgress()
//            //self.view.isUserInteractionEnabled = false
//            HttpWrapper.requestWithparamdictParamPostMethodwithHeader(url: a_userLikeDislike, dicsParams: dicParam, headers: ["Authorization":userModel.data?.api_token ?? ""], completion: { [self] (response) in
//                self.view.isUserInteractionEnabled = true
//                //AppHelper.hideLinearProgress()
//                let dicsResponseFinal = response.replaceNulls(with: "")
//                print(dicsResponseFinal as Any)
//                
//                let userLikeDislikeModel = UserLikeDislikeModel(JSON: dicsResponseFinal as! [String : Any])!
//                if userLikeDislikeModel.code == 200{
//                    //                    if customSwipe == "1"{
//                    //                        if like == "0"{
//                    //                            kolodaView.swipe(.right)
//                    //                        }else if like == "1"{
//                    //                            kolodaView.swipe(.left)
//                    //                        }
//                    //                    }
//                    
//                }else if userLikeDislikeModel.code == 401{
//                    AppHelper.Logout(navigationController: self.navigationController!)
//                } else if userLikeDislikeModel.code == 201{
//                    
//                    //                    resetKolodaView(index:index)
//                    
//                    //
//                    arrFlag[index] = 0
//                    self.collview.reloadData()
//                    
//                    //
//                    let obj = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "PremiumMembershipNewVC") as! PremiumMembershipNewVC
//                    //                    obj.strSubscriptionType = "Gold"
//                    //                    obj.type_subscription = SubscriptionType.swipe
//                    obj.strSubscriptionType = "Premium"
//                    obj.type_subscription = SubscriptionType.chat_swipe
//                    navigationController?.pushViewController(obj, animated: true)
//                } else if userLikeDislikeModel.code == 202 {
//                    
//                    let index1 = arrUserList.firstIndex { $0.id ==  Int(op_user_id)}
//                    
//                    if index1 != nil {
//                        
//                        //
//                        let obj = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MatchVC") as! MatchVC
//                        obj.userModel = arrUserList[index1!]
//                        obj.strReceiverId = op_user_id
//                        obj.delegate = self
//                        obj.modalPresentationStyle = .overFullScreen
//                        self.present(obj, animated: true, completion: nil)
//                    }
//                    
//                } else{
//                    self.view.makeToast(dicsResponseFinal?.object(forKey: "message") as? String ?? "")
//                }
//            }) { (error) in
//                print(error)
//                self.view.isUserInteractionEnabled = true
//                //AppHelper.hideLinearProgress()
//            }
//        }
//    }
    func apiCall_userList(page:Int) {
        if NetworkReachabilityManager()!.isReachable == false
        {
            let alert = UIAlertController(title: internetConnectedTitle.localizableString(lang: Helper.shared.strLanguage), message: internetConnected, preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK".localizableString(lang: Helper.shared.strLanguage), style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else
        {
            //--
            let age_minimum_filter = UserDefaults.standard.object(forKey: "age_minimum_filter") ?? "18"
            let age_maximum_filter = UserDefaults.standard.object(forKey: "age_maximum_filter") ?? "70"
            let distance_value_filter = UserDefaults.standard.object(forKey: "distance_value_filter") ?? "500"
            let status_filter = UserDefaults.standard.object(forKey: "status_filter") ?? OnlineStatus.no.rawValue
            let relationship_status_filter = UserDefaults.standard.object(forKey: "relationship_status_filter") ?? ""
            let denomination_filter = UserDefaults.standard.object(forKey: "denomination_filter") ?? ""
            let looking_for_filter = UserDefaults.standard.object(forKey: "looking_for_filter") ?? ""
            
            //--
            print("API CALLED")
            let dicParam:[String:AnyObject] = ["min_age":age_minimum_filter as AnyObject,
                                               "max_age":age_maximum_filter as AnyObject,
                                               "lat":latitude as AnyObject,
                                               "lng":longitude as AnyObject,
                                               "distance":distance_value_filter as AnyObject,
                                               "is_online_user":status_filter as AnyObject,
                                               "relation_status":relationship_status_filter as AnyObject,
                                               "denomination":denomination_filter as AnyObject,
                                               "looking_for":looking_for_filter as AnyObject,
                                               "page":page as AnyObject,
                                               "limit":5 as AnyObject]
            let userModel = Login_LocalDB.getLoginUserModel()
            //AppHelper.showLinearProgress()
            //self.view.isUserInteractionEnabled = false
            HttpWrapper.requestWithparamdictParamPostMethodwithHeader(url: a_userList, dicsParams: dicParam, headers: ["Authorization":userModel.data?.api_token ?? ""], completion: { [self] (response) in
                self.view.isUserInteractionEnabled = true
                //AppHelper.hideLinearProgress()
                let dicsResponseFinal = response.replaceNulls(with: "")
                print(dicsResponseFinal as Any)
                
                let userListModel = GetNearUserResponse(JSON: dicsResponseFinal as! [String : Any])!
                if userListModel.code == 200{
                    
                    
                    //
                    let dictPage = userListModel.data?[0].page
                    self.last_page = dictPage?["total_page"] as? Int ?? 0
                    print("LAST_PAGE:\(self.last_page)")
                    self.arrUserList += userListModel.data?[0].userlist ?? []
                    print(arrUserList)
                    for i in 0..<(userListModel.data?[0].userlist?.count ?? 0) {
                        
                        arrFlag.append(userListModel.data?[0].userlist?[i].is_liked_count ?? 0)
                    }
                    DispatchQueue.main.async {
                        if self.arrUserList.count == 0 {
//                            self.lblNoResultFound.isHidden = false
                            
                            UIView.animate(withDuration: 0.3) {
                                self.headerBGView.alpha = 1
                                self.lblLogosHeader.textColor = .black
                                self.btnFilter.tintColor = .black
                                self.btnVisibility.tintColor = .black
                                self.lblNoResultFound.alpha = 1
                            }

                        } else {
//                            self.lblNoResultFound.isHidden = true
                            
                            UIView.animate(withDuration: 0.3) {
                                self.headerBGView.alpha = 0
                                self.lblLogosHeader.textColor = .white
                                self.btnFilter.tintColor = .white
                                self.btnVisibility.tintColor = .white
                                self.lblNoResultFound.alpha = 0
                            }

                        }
                        
                        DispatchQueue.main.async {
//                            self.collview.reloadData()
                            self.kolodaView.reloadData()
                        }
                    }
                    
                    //                    let dictPage = userListModel.data?[0].page
                    //
                    //
                    //                    if (dictPage?["current_page"] as? Int ?? 0) <= (dictPage?["total_page"] as? Int ?? 0) {
                    //                        print((dictPage?["current_page"] as? Int ?? 0))
                    //
                    //                        if (dictPage?["current_page"] as? Int ?? 0) != (dictPage?["next_page"] as? Int ?? 0) {
                    //                            self.apiCall_userList(page: (dictPage?["next_page"] as? Int ?? 0))
                    //                        } else {
                    //                            print("Last page called")
                    //
                    //                        }
                    //
                    //                    }

                    
                }else if userListModel.code == 401{
                    AppHelper.Logout(navigationController: self.navigationController!)
                }else{
                    self.view.makeToast(dicsResponseFinal?.object(forKey: "message") as? String ?? "")
                }
            }) { (error) in
                print(error)
                self.view.isUserInteractionEnabled = true
                AppHelper.hideLinearProgress()
            }
        }
    }
    //EDIT
    //    func getUserDetailsAPI(qbId:String) {
    //
    //        if NetworkReachabilityManager()!.isReachable == false
    //        {
    //            return
    //        }
    //
    //        let dicParams:[String:String] = ["quickbox_id":qbId]
    //        AppHelper.showLinearProgress()
    //
    //        let userModel = Login_LocalDB.getLoginUserModel()
    //
    //        let headers:HTTPHeaders = ["Accept":"application/json",
    //                                   "Authorization":userModel.data?.api_token ?? ""]
    //
    //        AF.request(detail_by_quickbox, method: .post, parameters: dicParams, encoding: URLEncoding.default, headers: headers).responseJSON { response in
    //
    //            print(response)
    //
    //            if let json = response.value as? [String:Any] {
    //
    //                if json["status"] as? String == "Success" {
    //
    //                    let dict = json["data"] as? [String:Any]
    //
    //                    var imgName = ""
    //                    if (dict?["user_image"] as? [[String:Any]])?.count != 0{
    //                        let img = (dict?["user_image"] as? [[String:Any]])?[0]["image"] as? String
    //                        imgName = "\(kImageBaseURL)\(img ?? "")".replacingOccurrences(of: " ", with: "%20")
    //
    //                    }
    //
    //                    self.openAudioCallView(img:imgName, name:dict?["name"] as? String ?? "")
    //                }
    //            }
    //
    //            AppHelper.hideLinearProgress()
    //        }
    //    }
    
    func getChatCount() {
        
        let userModel = Login_LocalDB.getLoginUserModel()
        
        guard let networkManager = NetworkReachabilityManager(), networkManager.isReachable else {
            DispatchQueue.main.async {
                let alert = UIAlertController(
                    title: "internetConnectedTitle.localizableString(lang: Helper.shared.strLanguage)",
                    message: internetConnected.localizableString(lang: Helper.shared.strLanguage),
                    preferredStyle: .alert
                )
                alert.addAction(UIAlertAction(
                    title: "OK".localizableString(lang: Helper.shared.strLanguage),
                    style: .default
                ))
                self.present(alert, animated: true)
            }
            return
        }

        AF.request( get_chat_count, method: .get, headers: ["Authorization": userModel.data?.api_token ?? ""]).responseJSON { [weak self] response in
            guard let self = self else { return }
            
            DispatchQueue.main.async {
                do {
                    guard let json = response.value as? [String: Any] else {
                        print("Invalid JSON response")
                        return
                    }
                    
                    guard let code = json["code"] as? Int else {
                        print("Missing or invalid code")
                        return
                    }
                    
                    switch code {
                    case 200:
                        guard let tabItems = self.tabBarController?.tabBar.items, tabItems.count > 2, let data = json["data"] as? [String: Any] else {
                            return
                        }
                        
                        let tabItem = tabItems[2]
                        if let unreadCount = data["un_read_msg"] as? Int {
                            tabItem.badgeValue = unreadCount == 0 ? nil : "\(unreadCount)"
                        }
                        
                    case 401:
                        if let navigationController = self.navigationController {
                            AppHelper.Logout(navigationController: navigationController)
                        }
                        
                    default:
                        print("Unexpected response code: \(code)")
                    }
                }
            }
        }
    }
    
//    func getNotificationsAPI() {
//        
//        if NetworkReachabilityManager()!.isReachable == false
//        {
//            return
//        }
//        //AppHelper.showLinearProgress()
//        
//        let userModel = Login_LocalDB.getLoginUserModel()
//        
//        let dicParams:[String:Any] = ["user_id":userModel.data?.id ?? 0]
//        
//        
//        let headers:HTTPHeaders = ["Accept":"application/json"]
//        
//        AF.request(user_notification, method: .post, parameters: dicParams, encoding: URLEncoding.default, headers: headers).responseJSON { response in
//            
//            print(response)
//            
//            if let json = response.value as? [String:Any] {
//                
//                if json["status"] as? String == "Success" {
//                    
//                    self.arr = json["data"] as? [[String:Any]] ?? []
//                    
//                    DispatchQueue.main.async {
//                        
//                        self.setChatTabNotificationBadge()
//                    }
//                    
//                }
//            }
//            //AppHelper.hideLinearProgress()
//        }
//    }
    func apiCall_likedUserList() {
        if NetworkReachabilityManager()!.isReachable == false
        {
            let alert = UIAlertController(title: internetConnectedTitle.localizableString(lang: Helper.shared.strLanguage), message: internetConnected.localizableString(lang: Helper.shared.strLanguage), preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK".localizableString(lang: Helper.shared.strLanguage), style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else
        {
            //--
            let dicParam:[String:AnyObject] = [:]
            let userModel = Login_LocalDB.getLoginUserModel()
            //AppHelper.showLinearProgress()
            HttpWrapper.requestWithparamdictParamPostMethodwithHeader(url: a_likedUserList, dicsParams: dicParam, headers: ["Authorization":userModel.data?.api_token ?? ""], completion: { [self] (response) in
                self.view.isUserInteractionEnabled = true
                AppHelper.hideLinearProgress()
                let dicsResponseFinal = response.replaceNulls(with: "")
                print(dicsResponseFinal as Any)
                
                let userListModel = UserModel(JSON: dicsResponseFinal as! [String : Any])!
                if userListModel.code == 200{
                    
                    if let tabItems = self.tabBarController?.tabBar.items {
                        let tabItem = tabItems[1]
                        
                        if userListModel.dataList.count == 0 {
                            tabItem.badgeValue = nil
                        } else {
                            tabItem.badgeValue = "\(userListModel.dataList.count)"
                        }
                    }
                    
                }else if userListModel.code == 401{
                    AppHelper.Logout(navigationController: self.navigationController!)
                }else{
                    self.view.makeToast(dicsResponseFinal?.object(forKey: "message") as? String ?? "")
                }
            }) { (error) in
                print(error)
                self.view.isUserInteractionEnabled = true
                AppHelper.hideLinearProgress()
            }
        }
    }
    
    //EDIT
    //if dialog isnot created between two matches then creates it here
    //    func newMatchesAPI() {
    //
    //        if NetworkReachabilityManager()!.isReachable == false
    //        {
    //            return
    //        }
    //
    //        let userModel = Login_LocalDB.getLoginUserModel()
    //
    //        let params = ["flag":"1"]
    //
    //        let headers:HTTPHeaders = ["Accept":"application/json",
    //                                   "Authorization":userModel.data?.api_token ?? ""]
    //
    //        AF.request(new_matches, method: .post, parameters: params, encoding: URLEncoding.default, headers: headers).responseJSON { response in
    //
    //            //print(response)
    //
    //            if let json = response.value as? [String:Any] {
    //
    //                if json["status"] as? String == "Success" {
    //
    //                    let arr = json["data"] as? [[String:Any]]
    //
    //                    //dispatchGroup is for async task in for loop
    //                    let group = DispatchGroup()
    //
    //                    var counter = 0
    //
    //                    for i in 0..<(arr?.count ?? 0) {
    //                        group.enter()
    //
    //                        let str = arr?[i]["quickbox_id"] as? String
    //
    //                        if str != "" && str != nil {
    //                            self.createDialog1(quickbox_id: str!, index: i) { result in
    //                                defer { group.leave() }
    //                                print(result)
    //                                counter += 1
    //                            }
    //                        } else {
    //                            defer { group.leave() }
    //                            counter += 1
    //                        }
    //                    }
    //
    //                    group.notify(queue: DispatchQueue.main) {
    //                        print("All tasks done - \(counter)")
    //                    }
    //
    //                }
    //            }
    //        }
    //    }
    
    func sendOnlineUserStatusAPI() {
        
        if NetworkReachabilityManager()!.isReachable == false
        {
            return
        }
        
        let userModel = Login_LocalDB.getLoginUserModel()
        
        let headers:HTTPHeaders = ["Accept":"application/json",
                                   "Authorization":userModel.data?.api_token ?? ""]
        
        AF.request(online_user, method: .post, parameters: [:], encoding: URLEncoding.default, headers: headers).responseJSON { response in
            
            //print(response)
            
            if let json = response.value as? [String:Any] {
                
                if json["status"] as? String == "Success" {
                    
                    print(json["data"] as? [[String:Any]])
                    
                    
                } else {
                    
                    if json["code"] as? Int == 403 {
                        
                        AppHelper.Logout(navigationController: self.navigationController!)
                        
                        self.view.makeToast(json["message"] as? String ?? "")
                    }
                }
            }
        }
    }
    
    func getProfileStatusAPI() {
        
        if NetworkReachabilityManager()!.isReachable == false
        {
            return
        }
        
        let dicParams:[String:String] = [:]
        //AppHelper.showLinearProgress()
        
        let userModel = Login_LocalDB.getLoginUserModel()
        
        let headers:HTTPHeaders = ["Accept":"application/json",
                                   "Authorization":userModel.data?.api_token ?? ""]
        
        AF.request(get_profile_status, method: .post, parameters: dicParams, encoding: URLEncoding.default, headers: headers).responseJSON { response in
            
            print(response)
            
            if let json = response.value as? [String:Any] {
                
                if json["status"] as? String == "Success" {
                    
                    let dict = (json["data"] as? [[String:Any]])?[0] as? [String:Any]
                    
                    if dict?["is_public"] as? Int == 0 {
                        self.btnVisibility.setImage(UIImage(named: "eye_hide"), for: .normal)
                    } else {
                        self.btnVisibility.setImage(UIImage(named: "eye_show"), for: .normal)
                    }
                }
            }
            
            //AppHelper.hideLinearProgress()
        }
    }
    
    func apiCall_updateProfile(lat:String, lng:String, address:String, state:String, country:String, country_code:String)  {
        if NetworkReachabilityManager()!.isReachable == false
        {
            let alert = UIAlertController(title: internetConnectedTitle.localizableString(lang: Helper.shared.strLanguage), message: internetConnected.localizableString(lang: Helper.shared.strLanguage), preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK".localizableString(lang: Helper.shared.strLanguage), style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else
        {
            
            let userModel = Login_LocalDB.getLoginUserModel()
            
            //--
            let dicParam:[String:AnyObject] = ["lat":lat as AnyObject,
                                               "lng":lng as AnyObject,
                                               "address":address as AnyObject,
                                               "city":state as AnyObject,
                                               "country":country as AnyObject,
                                               "country_code":country_code as AnyObject]
            
            //AppHelper.showLinearProgress()
            self.view.isUserInteractionEnabled = false
            HttpWrapper.requestMultipartFormDataWithImageAndFile(a_updateProfile, dicsParams: dicParam, headers: ["Authorization":userModel.data?.api_token ?? ""], completion: { (response) in
                self.view.isUserInteractionEnabled = true
                //AppHelper.hideLinearProgress()
                let dicsResponseFinal = response.replaceNulls(with: "")
                print(dicsResponseFinal as Any)
                
                let userListModel_ = UserModel(JSON: dicsResponseFinal as! [String : Any])!
                if userListModel_.code == 200{
                    //--
                    if let userListModel_ = UserModel(JSON: dicsResponseFinal as! [String : Any])!.toJSONString(){
                        Login_LocalDB.saveLoginInfo(strData: userListModel_)
                    }
                    
                    //show alert if zodiac is not added in profile
                    if userListModel_.data?.your_zodiac == "" {
                        self.showZodiacAlert()
                    }
                    
                }else if userListModel_.code == 401{
                    AppHelper.Logout(navigationController: self.navigationController!)
                }else{
                    self.view.makeToast(dicsResponseFinal?.object(forKey: "message") as? String ?? "")
                }
            }) { (error) in
                print(error)
                self.view.isUserInteractionEnabled = true
                AppHelper.hideLinearProgress()
            }
        }
    }
    
    
    func startChat(userData: UserData) {
        
        if ManageSubscriptionInfo.getSubscriptionModel().data?.is_buy_valid_subscription_new == "0" || ManageSubscriptionInfo.getSubscriptionModel().data?.is_buy_valid_subscription_new == "" {
            
            let obj = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "PremiumMembershipNewVC") as! PremiumMembershipNewVC
            obj.strSubscriptionType = "Premium"
            obj.type_subscription = SubscriptionType.chat_swipe
            navigationController?.pushViewController(obj, animated: true)
            return
        }
        if ManageSubscriptionInfo.getSubscriptionModel().data?.is_buy_valid_subscription_new == "1" && ManageSubscriptionInfo.getSubscriptionModel().data?.type == "Swipe" {
            
            let obj = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "PremiumMembershipNewVC") as! PremiumMembershipNewVC
            obj.strSubscriptionType = "Premium"
            obj.type_subscription = SubscriptionType.chat_swipe
            navigationController?.pushViewController(obj, animated: true)
            return
        }
        
        print(userData.room_info)
        
        var dictRoomInfo:[String:Any]?
        if userData.room_info.count != 0 {
            dictRoomInfo = userData.room_info[0]
        }
        
        
        let vc = OnetoOneChatVC(nibName: "OnetoOneChatVC", bundle: nil)
        
        vc.strReceiverId = "\(userData.id ?? 0)"
        if let room_id = dictRoomInfo?["room_id"] as? String {
            vc.strRoomId = room_id
        } else {
            vc.strRoomId = "no"//if there is no room created then pass "no" to get empty array with 200 response. As Passing empty string ll not give 200 response
        }
        self.navigationController?.pushViewController(vc, animated: true)
        //EDIT
        //let quickbox_id = "\(userData?.quickbox_id ?? "")"
        //processChat(quickbox_id: quickbox_id)
    }
    
    
    func apiCallUserLikeDislike(like: String, op_user_id: String, index:Int) {
        
        if NetworkReachabilityManager()!.isReachable == false {
            let alert = UIAlertController(title: internetConnectedTitle.localizableString(lang: Helper.shared.strLanguage), message: internetConnected, preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK".localizableString(lang: Helper.shared.strLanguage), style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
        } else {
            //--
            let dicParam:[String:AnyObject] = ["op_user_id":op_user_id as AnyObject,
                                               "flag":like as AnyObject,
                                               "plan_purchased":ManageSubscriptionInfo.getSubscriptionModel().data?.is_buy_valid_subscription_new as AnyObject]
            
            let userModel = Login_LocalDB.getLoginUserModel()
            //AppHelper.showLinearProgress()
            //self.view.isUserInteractionEnabled = false
            HttpWrapper.requestWithparamdictParamPostMethodwithHeader(url: a_userLikeDislike, dicsParams: dicParam, headers: ["Authorization":userModel.data?.api_token ?? ""], completion: { [self] (response) in
                self.view.isUserInteractionEnabled = true
                //AppHelper.hideLinearProgress()
                let dicsResponseFinal = response.replaceNulls(with: "")
                print(dicsResponseFinal as Any)
                
                let userLikeDislikeModel = UserLikeDislikeModel(JSON: dicsResponseFinal as! [String : Any])!
                
                if userLikeDislikeModel.code == 200 {
                    
                    if like == "0" {
                        self.kolodaView?.swipe(.right)
                    } else {
                        self.kolodaView?.swipe(.left)
                    }
//                    self.apiCall_userList(page: currentPage)
                    
                } else if userLikeDislikeModel.code == 401 {
                    AppHelper.Logout(navigationController: self.navigationController!)
                    
                } else if userLikeDislikeModel.code == 201 {
                    
                    //                    resetKolodaView(index:index)
//                    
                    
//                    arrFlag[index] = 0
//                    self.collview.reloadData()
                    
                    
                    let obj = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "PremiumMembershipNewVC") as! PremiumMembershipNewVC
                    //                    obj.strSubscriptionType = "Gold"
                    //                    obj.type_subscription = SubscriptionType.swipe
                    obj.strSubscriptionType = "Premium"
                    obj.type_subscription = SubscriptionType.chat_swipe
                    navigationController?.pushViewController(obj, animated: true)
                    
                } else if userLikeDislikeModel.code == 202 {
                    
                    let index1 = arrUserList.firstIndex { $0.id ==  Int(op_user_id)}
                    
                    if index1 != nil {
                        
                        //
                        self.kolodaView?.swipe(.left)
                        
                        let obj = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MatchVC") as! MatchVC
                        obj.userModel = arrUserList[index1!]
                        obj.strReceiverId = op_user_id
                        obj.delegate = self
                        obj.modalPresentationStyle = .overFullScreen
                        self.present(obj, animated: true, completion: nil)
                    }
                    
                } else {
                    self.view.makeToast(dicsResponseFinal?.object(forKey: "message") as? String ?? "")
                }
            }) { (error) in
                print(error)
                self.view.isUserInteractionEnabled = true
                //AppHelper.hideLinearProgress()
            }
        }
    }
    
    
    // In HomeVC
//    func apiCallUserLikeDislike(like: String, op_user_id: String, index: Int) {
//        // Check network reachability
//        guard NetworkReachabilityManager()?.isReachable == true else {
//            let alert = UIAlertController(
//                title: internetConnectedTitle.localizableString(lang: Helper.shared.strLanguage),
//                message: internetConnected,
//                preferredStyle: .alert
//            )
//            alert.addAction(UIAlertAction(
//                title: "OK".localizableString(lang: Helper.shared.strLanguage),
//                style: .default
//            ))
//            present(alert, animated: true)
//            return
//        }
//        
//        // Prepare parameters
//        let dicParam: [String: Any] = [
//            "op_user_id": op_user_id,
//            "flag": like,
//            "plan_purchased": ManageSubscriptionInfo.getSubscriptionModel().data?.is_buy_valid_subscription_new ?? ""
//        ]
//        
//        let userModel = Login_LocalDB.getLoginUserModel()
//        
//        // Make API call with proper error handling
//        AF.request(a_userLikeDislike,
//                  method: .post,
//                  parameters: dicParam,
//                  encoding: JSONEncoding.default,
//                  headers: ["Authorization": userModel.data?.api_token ?? ""])
//        .validate()
//        .responseData { [weak self] response in
//            guard let self = self else { return }
//            self.view.isUserInteractionEnabled = true
//            
//            switch response.result {
//            case .success(let data):
//                // Log raw response for debugging
//                if let rawString = String(data: data, encoding: .utf8) {
//                    print("Raw Response: \(rawString)")
//                }
//                
//                do {
//                    // First, try to clean the response data
//                    let cleanedData: Data
//                    if let rawString = String(data: data, encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines),
//                       let cleanData = rawString.data(using: .utf8) {
//                        cleanedData = cleanData
//                    } else {
//                        cleanedData = data
//                    }
//                    
//                    // Try to parse as dictionary first
//                    let responseDict = try JSONSerialization.jsonObject(with: cleanedData, options: []) as? [String: Any] ?? [:]
//                    
//                    // Replace null values with empty string
//                    let cleanDict = responseDict.replaceNulls(with: "")
//                    
//                    // Create model from cleaned dictionary
//                    if let userLikeDislikeModel = UserLikeDislikeModel(JSON: cleanDict) {
//                        // Handle response based on code
//                        switch userLikeDislikeModel.code {
//                        case 200:
//                            if like == "0" {
//                                self.kolodaView?.swipe(.right)
//                            } else {
//                                self.kolodaView?.swipe(.left)
//                            }
//                            
//                        case 401:
//                            AppHelper.Logout(navigationController: self.navigationController!)
//                            
//                        case 201:
//                            let obj = UIStoryboard(name: "Main", bundle: nil)
//                                .instantiateViewController(withIdentifier: "PremiumMembershipNewVC") as! PremiumMembershipNewVC
//                            obj.strSubscriptionType = "Premium"
//                            obj.type_subscription = SubscriptionType.chat_swipe
//                            self.navigationController?.pushViewController(obj, animated: true)
//                            
//                        case 202:
//                            if let index = self.arrUserList.firstIndex(where: { $0.id == Int(op_user_id) }) {
//                                self.kolodaView?.swipe(.left)
//                                
//                                let obj = UIStoryboard(name: "Main", bundle: nil)
//                                    .instantiateViewController(withIdentifier: "MatchVC") as! MatchVC
//                                obj.userModel = self.arrUserList[index]
//                                obj.strReceiverId = op_user_id
//                                obj.delegate = self
//                                obj.modalPresentationStyle = .overFullScreen
//                                self.present(obj, animated: true)
//                            }
//                            
//                        default:
//                            if let message = cleanDict["message"] as? String {
//                                self.view.makeToast(message)
//                            }
//                        }
//                    } else {
//                        self.view.makeToast("Failed to parse response")
//                    }
//                } catch {
//                    print("JSON Parsing Error: \(error)")
//                    self.view.makeToast("Failed to process response")
//                }
//                
//            case .failure(let error):
//                print("API Error: \(error)")
//                
//                // Handle specific AFError cases
//                if let afError = error.asAFError {
//                    switch afError {
//                    case .responseSerializationFailed(let reason):
//                        print("Serialization Failed: \(reason)")
//                        // Try to get error message from response
//                        if let data = response.data,
//                           let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
//                           let message = json["message"] as? String {
//                            self.view.makeToast(message)
//                            return
//                        }
//                    default:
//                        break
//                    }
//                }
//                
//                self.view.makeToast(error.localizedDescription)
//            }
//        }
//    }
    
    
    
    
    
    
    
    
    
    
    //EDIT
    //    func createDialog1(quickbox_id:String, index: Int, completion: @escaping (String) -> Void) {
    //
    //        let user = NSNumber(value: QBSession.current.currentUser!.id)
    //        let receiver = NSNumber(value: UInt(Int(quickbox_id)!))
    //
    //        let arr:[NSNumber] = [receiver,user]
    //
    //        let index1 = arrDialogs?.firstIndex{$0.occupantIDs == arr}
    //
    //        if let _ = index1 {
    //
    //            completion("Async Task \(index) Done")
    //        } else {
    //
    //            let arr2:[NSNumber] = [user,receiver]
    //
    //            let index2 = arrDialogs?.firstIndex{$0.occupantIDs == arr2}
    //
    //            if let _ = index2 {
    //
    //                completion("Async Task \(index) Done")
    //            } else {
    //
    //                //create dialog
    //                let num = NSNumber(value: UInt(Int(quickbox_id)!))
    //                let num2 = NSNumber(value: QBSession.current.currentUser!.id)
    //
    //                let chatDialog = QBChatDialog(dialogID: nil, type: .group)
    //                chatDialog.name = "match \(num2)"//"New group dialog"
    //                chatDialog.occupantIDs = [num,num2]
    //                // Photo can be a link to a file in Content module, Custom Objects module or just a web link.
    //                // dialog.photo = "...";
    //
    //                QBRequest.createDialog(chatDialog, successBlock: { (response, dialog) in
    //                    dialog.join(completionBlock: { (error) in
    //                    })
    //                    //print(response)
    //                    //print(dialog)
    //                    completion("Async Task \(index) Done")
    //                }, errorBlock: { (response) in
    //                    //print(response)
    //                    completion("Async Task \(index) Done")
    //                })
    //            }
    //        }
    //    }
    
    
    
    
    //MARK: - @IBAction
    
    @IBAction func btnVisibility(_ sender: Any) {
        
        let obj = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "VisibilityVC") as! VisibilityVC
        navigationController?.pushViewController(obj, animated: true)
    }
    @IBAction func btnFilter(_ sender: Any) {
        
        //--
        let vc = FilterVC(nibName: "FilterVC", bundle: nil)
        vc.delegate = self
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnTopViewExplore(_ sender: UIButton) {
        
        btnExplore.setTitleColor(UIColor.black, for: .normal)
        btnRelationship.setTitleColor(UIColor(named: "AppGray"), for: .normal)
        btnMarriage.setTitleColor(UIColor(named: "AppGray"), for: .normal)
        btnOnline.setTitleColor(UIColor(named: "AppGray"), for: .normal)
        
        //
        UserDefaults.standard.setValue(nil, forKey: "looking_for_filter")
        UserDefaults.standard.setValue(nil, forKey: "status_filter")
        UserDefaults.standard.synchronize()
        
        //
        reloadData()
    }
    
    @IBAction func btnTopViewRelationship(_ sender: UIButton) {
        
        btnExplore.setTitleColor(UIColor(named: "AppGray"), for: .normal)
        btnRelationship.setTitleColor(UIColor.black, for: .normal)
        btnMarriage.setTitleColor(UIColor(named: "AppGray"), for: .normal)
        btnOnline.setTitleColor(UIColor(named: "AppGray"), for: .normal)
        
        UserDefaults.standard.setValue("Relationship", forKey: "looking_for_filter")
        UserDefaults.standard.setValue(nil, forKey: "status_filter")
        UserDefaults.standard.synchronize()
        
        //
        reloadData()
    }
    
    @IBAction func btnTopViewMarriage(_ sender: UIButton) {
        
        btnExplore.setTitleColor(UIColor(named: "AppGray"), for: .normal)
        btnRelationship.setTitleColor(UIColor(named: "AppGray"), for: .normal)
        btnMarriage.setTitleColor(UIColor.black, for: .normal)
        btnOnline.setTitleColor(UIColor(named: "AppGray"), for: .normal)
        
        UserDefaults.standard.setValue("Marriage", forKey: "looking_for_filter")
        UserDefaults.standard.setValue(nil, forKey: "status_filter")
        UserDefaults.standard.synchronize()
        
        //
        reloadData()
    }
    
    
    
    @IBAction func btnTopViewOnline(_ sender: Any) {
        
        btnExplore.setTitleColor(UIColor(named: "AppGray"), for: .normal)
        btnRelationship.setTitleColor(UIColor(named: "AppGray"), for: .normal)
        btnMarriage.setTitleColor(UIColor(named: "AppGray"), for: .normal)
        btnOnline.setTitleColor(UIColor.black, for: .normal)
        
        UserDefaults.standard.setValue(nil, forKey: "looking_for_filter")
        UserDefaults.standard.setValue(OnlineStatus.yes.rawValue, forKey: "status_filter")
        UserDefaults.standard.synchronize()
        
        //
        reloadData()
    }
    
    
    
    
    
    @objc func btnLikeDislike(sender: UIButton){
        
        if arrFlag[sender.tag] == 1 {
            //arrFlag[sender.tag] = 0
            //dislike
            //apiCall_userLikeDislike(like: "1",op_user_id: "\(arrUserList[sender.tag].id)", customSwipe: "", index: sender.tag)
        } else {
            arrFlag[sender.tag] = 1
            //like
//            apiCall_userLikeDislike(like: "0",op_user_id: "\(arrUserList[sender.tag].id)", customSwipe: "", index: sender.tag)
        }
        collview.reloadData()
    }
    
    @objc func btnChat(sender: UIButton) {
        
        
        //
        if ManageSubscriptionInfo.getSubscriptionModel().data?.is_buy_valid_subscription_new == "0" || ManageSubscriptionInfo.getSubscriptionModel().data?.is_buy_valid_subscription_new == "" {
            
            let obj = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "PremiumMembershipNewVC") as! PremiumMembershipNewVC
            obj.strSubscriptionType = "Premium"
            obj.type_subscription = SubscriptionType.chat_swipe
            navigationController?.pushViewController(obj, animated: true)
            return
        }
        if ManageSubscriptionInfo.getSubscriptionModel().data?.is_buy_valid_subscription_new == "1" && ManageSubscriptionInfo.getSubscriptionModel().data?.type == "Swipe" {
            
            let obj = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "PremiumMembershipNewVC") as! PremiumMembershipNewVC
            obj.strSubscriptionType = "Premium"
            obj.type_subscription = SubscriptionType.chat_swipe
            navigationController?.pushViewController(obj, animated: true)
            return
        }
        
        //EDIT
        //let quickbox_id = "\(arrUserList[sender.tag].quickbox_id)"
        //processChat(quickbox_id: quickbox_id)
        
        print(arrUserList[sender.tag].room_info)
        
        var dictRoomInfo:[String:Any]?
        if arrUserList[sender.tag].room_info.count != 0 {
            dictRoomInfo = arrUserList[sender.tag].room_info[0]
        }
        
        
        let vc = OnetoOneChatVC(nibName: "OnetoOneChatVC", bundle: nil)
        
        vc.strReceiverId = "\(arrUserList[sender.tag].id)"
        if let room_id = dictRoomInfo?["room_id"] as? String {
            vc.strRoomId = room_id
        } else {
            vc.strRoomId = "no"//if there is no room created then pass "no" to get empty array with 200 response. As Passing empty string ll not give 200 response
        }
        vc.delegate = self
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    //EDIT
    //    func getAllDialogs() {
    //
    //        //get dialogs that have been updated during the last month and sort by the date of the last message in descending order
    //        //let monthAgoDate = Calendar.current.date( byAdding: .month, value: -1, to: Date())
    //        //let timeInterval = monthAgoDate!.timeIntervalSince1970
    //
    //        let paramSort = "sort_desc"
    //        let sortValue = "last_message_date_sent"
    //        //let paramFilter = "updated_at[gte]"
    //        //let filterValue = "\(timeInterval)"
    //
    //        var extendedRequest: [String: String] = [:]
    //        extendedRequest[paramSort] = sortValue
    //        //extendedRequest[paramFilter] = filterValue
    //        let responsePage = QBResponsePage(limit: 0)
    //
    //        QBRequest.dialogs(for: responsePage, extendedRequest: extendedRequest, successBlock: { response, dialogs, dialogsUsersIDs, page in
    //
    //            print(dialogs)
    //            self.arrDialogs = dialogs
    //
    //            //
    //            DispatchQueue.global(qos: .userInitiated).async {
    //                print("This is run on a background queue")
    //                self.newMatchesAPI()
    //            }
    //        }, errorBlock: { response in
    //
    //        })
    //    }
    //EDIT
    /*func createDialog(userId:UInt) {
     
     let num = NSNumber(value: userId)
     let num2 = NSNumber(value: QBSession.current.currentUser!.id)
     
     let chatDialog = QBChatDialog(dialogID: nil, type: .group)
     chatDialog.name = "direct_chat \(num2)"//"New group dialog"
     chatDialog.occupantIDs = [num,num2]
     // Photo can be a link to a file in Content module, Custom Objects module or just a web link.
     // dialog.photo = "...";
     
     QBRequest.createDialog(chatDialog, successBlock: { (response, dialog) in
     dialog.join(completionBlock: { (error) in
     })
     print(response)
     print(dialog)
     
     let vc = OnetoOneChatVC(nibName: "OnetoOneChatVC", bundle: nil)
     vc.dictReceiver = dialog
     self.navigationController?.pushViewController(vc, animated: true)
     }, errorBlock: { (response) in
     
     })
     
     //        let dialog = QBChatDialog(dialogID: nil, type: .private)
     //        dialog.occupantIDs = [num]
     //        QBRequest.createDialog(dialog, successBlock: { (response, createdDialog) in
     //
     //            print(createdDialog)
     //        }, errorBlock: { (response) in
     //            print(response)
     //        })
     }*/
    
    
    
    
}


extension HomeVC:UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        //        if arrUserList.count == 0 {
        //            lblNoResultFound.isHidden = false
        //        } else {
        //            lblNoResultFound.isHidden = true
        //        }
        return arrUserList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "HomeCollCell", for: indexPath) as! HomeCollCell
        
        if arrUserList.count != 0 {
            
            //--
            var imgName = arrUserList[indexPath.row].user_image.first?.image ?? ""
            imgName = "\(kImageBaseURL)\(imgName)".replacingOccurrences(of: " ", with: "%20")
            
            //--
            ImageLoader().imageLoad(imgView: cell.imgMain, url: imgName)
            
            //--
            let dob_str = arrUserList[indexPath.row].dob
            let dob_year = AppHelper.stringToDate(strDate: dob_str, strFormate: "yyyy-MM-dd")
            
            cell.lblTitle.text = "\(arrUserList[indexPath.row].name), \(Date().years(from: dob_year))"
            cell.lblDetail.text = "\(arrUserList[indexPath.row].city), \(arrUserList[indexPath.row].country)"
            
            
            
            //
            let strDeno = "\(((arrUserList[indexPath.row].denomination_id).replacingOccurrences(of: "[", with: "")).replacingOccurrences(of: "]", with: ""))"
            cell.lblDenomination.text = strDeno
            
            //
            if arrUserList[indexPath.row].is_online == 1 {// 1 online
                
                cell.imgOnline.isHidden = false
                //cell.imgOnline.image = #imageLiteral(resourceName: "green-circle")
                cell.lblOnlineStatus.text = ""
                cell.lblOnlineDot.isHidden = true
                
            } else if arrUserList[indexPath.row].is_online == 2 {// 2 recently online
                
                cell.imgOnline.isHidden = true
                //cell.imgOnline.image = #imageLiteral(resourceName: "gray-circle")
                cell.lblOnlineStatus.text = "Recently Online"
                cell.lblOnlineDot.isHidden = false
                
            } else if arrUserList[indexPath.row].is_online == 0 {// 0 offline
                
                cell.imgOnline.isHidden = true
                //cell.imgOnline.image = #imageLiteral(resourceName: "gray-circle")
                cell.lblOnlineStatus.text = ""
                cell.lblOnlineDot.isHidden = true
                
            }
            
            if arrFlag[indexPath.row] == 0 {
                cell.btnLikeDislike.setImage(UIImage(named: "ic_like"), for: .normal)
            } else {
                cell.btnLikeDislike.setImage(UIImage(named: "ic_likes_active"), for: .normal)
            }
            
            //         if Helper.shared.strLanguage == "ar"  {
            //             cell.lblTitle.semanticContentAttribute = .forceRightToLeft
            //             cell.lblDetail.semanticContentAttribute = .forceRightToLeft
            //         }
            
            
            //--
            //        if ManageSubscriptionInfo.getSubscriptionModel().data?.is_buy_valid_subscription_new == "1" {
            //            cell?.viewbg_chat.isHidden = false
            //        }else{
            //            cell?.viewbg_chat.isHidden = true
            //        }
            
            //--
            cell.btnLikeDislike.tag = indexPath.row
            cell.btnLikeDislike.addTarget(self, action: #selector(btnLikeDislike(sender:)), for: .touchUpInside)
            cell.btnChat.tag = indexPath.row
            cell.btnChat.addTarget(self, action: #selector(btnChat(sender:)), for: .touchUpInside)
        }
        
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        //--
        selectIndexForDetailProfile = indexPath.row
        
        //--
        let vc = OtherProfileVC(nibName: "OtherProfileVC", bundle: nil)
        //vc.userData = arrUserList[indexPath.row]
        vc.delegate = self
        //vc.is_liked_count = arrFlag[indexPath.row]
        vc.intUserId = arrUserList[indexPath.row].id
        vc.intSelectedIndex = indexPath.row
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (collectionView.frame.width/2)-1, height: 280)
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        
//        if intCountArr != self.arrUserList.count {
//            if (indexPath.row == (self.arrUserList.count ) - 1 ) { //it's your last cell
//                if last_page != currentPage {
//                    
//                    //Load more data & reload your collection view
//                    print("Last row")
//                    currentPage = currentPage + 1
//                    intCountArr = self.arrUserList.count
//                    apiCall_userList(page: currentPage)
//                }
//                
//            }
//        }
    }
}


extension HomeVC: CLLocationManagerDelegate
{
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let locValue: CLLocationCoordinate2D = manager.location?.coordinate else { return }
        //print("locations = \(locValue.latitude) \(locValue.longitude)")
        if latitude == "" && longitude == ""
        {
            latitude = "\(manager.location?.coordinate.latitude ?? 0.0)"
            longitude = "\(manager.location?.coordinate.longitude ?? 0.0)"
            
        }
        
        
        let userModel = Login_LocalDB.getLoginUserModel()
        if userModel.data?.lat == "" && userModel.data?.lng == ""
        {
            
            locationManager.delegate = nil
            getAddressFromCoords(latitude: "\(manager.location?.coordinate.latitude ?? 0.0)", longitude: "\(manager.location?.coordinate.longitude ?? 0.0)")
        }
    }
    
    func getAddressFromCoords(latitude: String, longitude: String) {
        var center : CLLocationCoordinate2D = CLLocationCoordinate2D()
        let lat: Double = Double("\(latitude)")!
        //21.228124
        let lon: Double = Double("\(longitude)")!
        //72.833770
        let ceo: CLGeocoder = CLGeocoder()
        center.latitude = lat
        center.longitude = lon
        //ceo.accessibilityLanguage = "en-US"
        
        let locale = Locale(identifier: "en_US")
        
        let loc: CLLocation = CLLocation(latitude:center.latitude, longitude: center.longitude)
        
        ceo.reverseGeocodeLocation(loc, preferredLocale: locale, completionHandler:
                                    {(placemarks, error) in
            if (error != nil)
            {
                print("reverse geodcode fail: \(error!.localizedDescription)")
            }
            let pm = placemarks! as [CLPlacemark]
            
            if pm.count > 0 {
                let pm = placemarks![0]
                print(pm.country)
                print(pm.locality)
                print(pm.subLocality)
                print(pm.thoroughfare)
                print(pm.postalCode)
                print(pm.subThoroughfare)
                
                
                var addressString : String = ""
                var stateString : String = ""
                var countryString : String = ""
                var country_codeString : String = ""
                
                //                        if place.name != nil {
                //                            addressString = addressString + place.name! + ", "
                //                        }
                if pm.subLocality != nil {
                    addressString = addressString + pm.subLocality! + ", "
                }
                if pm.locality != nil {
                    addressString = addressString + pm.locality! + ", "
                    //cityString = pm.locality!
                }
                if pm.administrativeArea != nil {
                    addressString = addressString + pm.administrativeArea! + ", "
                    stateString = pm.administrativeArea!
                }
                if pm.country != nil {
                    addressString = addressString + pm.country! + ", "
                    countryString = pm.country!
                }
                if pm.postalCode != nil {
                    addressString = addressString + pm.postalCode! + " "
                }
                
                print(addressString)
                
                //
                self.apiCall_updateProfile(lat: "\(loc.coordinate.latitude)", lng: "\(loc.coordinate.longitude)", address: addressString, state: stateString, country: countryString, country_code: country_codeString)
            }
        })
        
    }
}

//EDIT
//extension HomeVC: QBRTCClientDelegate {
//
//    //audio call
//    func didReceiveNewSession(_ session: QBRTCSession, userInfo: [String : String]? = nil) {
//
//        if HelperAudioCall.shared.session != nil {
//            // we already have a video/audio call session, so we reject another one
//            // userInfo - the custom user information dictionary for the call from caller. May be nil.
//            let userInfo = ["key":"value"] // optional
//            session.rejectCall(userInfo)
//            return
//        }
//        // saving session instance here
//        HelperAudioCall.shared.session = session
//
//        HelperAudioCall.shared.isCallReceived = true
//
//        getUserDetailsAPI(qbId:"\(session.initiatorID)")
//        HelperAudioCall.shared.playSound()
//
//    }
//
//    func session(_ session: QBRTCSession, userDidNotRespond userID: NSNumber) {
//        HelperAudioCall.shared.session = nil
//        cancelTimer()
//        appDelegate.window?.viewWithTag(5001)?.removeFromSuperview()
//        AppHelper.returnTopNavigationController().view.makeToast("No answer".localizableString(lang: Helper.shared.strLanguage))
//        HelperAudioCall.shared.stopSound()
//    }
//
//    func session(_ session: QBRTCSession, acceptedByUser userID: NSNumber, userInfo: [String : String]? = nil) {
//
//        (appDelegate.window?.viewWithTag(5001) as? AudioCallView)?.lblTimer.isHidden = false
//        HelperAudioCall.shared.stopSound()
//        startTimer()
//        (appDelegate.window?.viewWithTag(5001) as? AudioCallView)?.btnAcceptCall.isHidden = true
//        (appDelegate.window?.viewWithTag(5001) as? AudioCallView)?.btnRejectCall.isHidden = true
//        (appDelegate.window?.viewWithTag(5001) as? AudioCallView)?.btnHungUp.isHidden = false
//        (appDelegate.window?.viewWithTag(5001) as? AudioCallView)?.btnMute.isHidden = false
//        (appDelegate.window?.viewWithTag(5001) as? AudioCallView)?.btnSpeaker.isHidden = false
//    }
//
//    func session(_ session: QBRTCSession, rejectedByUser userID: NSNumber, userInfo: [String : String]? = nil) {
//        print("Rejected by user \(userID)")
//        HelperAudioCall.shared.session = nil
//        cancelTimer()
//        appDelegate.window?.viewWithTag(5001)?.removeFromSuperview()
//        AppHelper.returnTopNavigationController().view.makeToast("Rejected".localizableString(lang: Helper.shared.strLanguage))
//        HelperAudioCall.shared.stopSound()
//    }
//
//    func session(_ session: QBRTCSession, hungUpByUser userID: NSNumber, userInfo: [String : String]? = nil) {
//
//        HelperAudioCall.shared.session = nil
//        AppHelper.returnTopNavigationController().view.makeToast("Hung up".localizableString(lang: Helper.shared.strLanguage))
//        cancelTimer()
//        appDelegate.window?.viewWithTag(5001)?.removeFromSuperview()
//    }
//
//    //this method gets called when our app in background and opponent hang up call
//    func session(_ session: QBRTCBaseSession, didChangeRconnectionState state: QBRTCReconnectionState, forUser userID: NSNumber) {
//
//        let state = UIApplication.shared.applicationState
//        if state == .background {
//            print("App in Background")
//            HelperAudioCall.shared.session = nil
//            //AppHelper.returnTopNavigationController().view.makeToast("Hung up".localizableString(lang: Helper.shared.strLanguage))
//            cancelTimer()
//            appDelegate.window?.viewWithTag(5001)?.removeFromSuperview()
//        }
//
//    }
//}
extension HomeVC: Filter {
    func applyFilter() {
        //
        reloadData()
    }
}
extension HomeVC: ProfileDetails {
    func likeDislikeFromProfileDetails(likeStatus:Int, selectedIndex:Int) {
        //
        
        arrFlag[selectedIndex] = likeStatus
        collview.reloadData()
    }
    
    func backButtonClicked(flag: Bool) {
        
        isFromHomeDetailsScreen = true
    }
}
extension HomeVC: SendMsgBtnMatchUI {
    
    func sendMsgBtnClick(strReceiverId: String, strRoomId: String) {
        
        let vc = OnetoOneChatVC(nibName: "OnetoOneChatVC", bundle: nil)
        vc.strReceiverId = strReceiverId
        vc.strRoomId = strRoomId
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}






//MARK: - Koloda View methods -
extension HomeVC: KolodaViewDataSource {
    func koloda(_ koloda: Koloda.KolodaView, viewForCardAt index: Int) -> UIView {
        
        let cell = Bundle.main.loadNibNamed("ProfileOverlayView", owner: self, options: nil)?[0] as? ProfileOverlayView
//        
//        if !self.arrUserList.isEmpty {
//            cell?.userData = self.arrUserList[index]
//        }

        if !self.arrUserList.isEmpty {
            guard index < self.arrUserList.count else {
                buttonEnable(false)
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                    buttonEnable(true)
                    
                    guard index < self.arrUserList.count else {
                        print("Error: Index \(index) is still out of bounds after delay.")
                        return
                    }
                    
                    cell?.userData = self.arrUserList[index]
                }
                
                // Ensure a view is always returned
                return cell ?? ProfileOverlayView()
            }
            
            cell?.userData = self.arrUserList[index]
        }

        
        cell?.btnCancelAction = {
            print(index)
            
            guard index < self.arrUserList.count else {
                buttonEnable(false)
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                    buttonEnable(true)
                    
                    guard index < self.arrUserList.count else {
                        print("Error: Index \(index) is still out of bounds after delay.")
                        return
                    }
                    
                    let userData = self.arrUserList[index]
                    self.apiCallUserLikeDislike(like: "1", op_user_id: "\(userData.id)", index: index)
                }
                return
            }
                
            let userData = self.arrUserList[index]
            self.apiCallUserLikeDislike(like: "1", op_user_id: "\(userData.id)", index: index)

        }
        
        cell?.btnLikeAction = {
            print(index)
            
            guard index < self.arrUserList.count else {
                buttonEnable(false)
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                    buttonEnable(true)

                    guard index < self.arrUserList.count else {
                        print("Error: Index \(index) is still out of bounds after delay.")
                        return
                    }
                    
                    let userData = self.arrUserList[index]
                    self.apiCallUserLikeDislike(like: "0", op_user_id: "\(userData.id)", index: index)
                }
                return
            }

            let userData = self.arrUserList[index]
            self.apiCallUserLikeDislike(like: "0", op_user_id: "\(userData.id)", index: index)
        }
        
        cell?.btnCommentAction = {
            
            guard index < self.arrUserList.count else {
                buttonEnable(false)
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                    buttonEnable(true)

                    guard index < self.arrUserList.count else {
                        print("Error: Index \(index) is still out of bounds after delay.")
                        return
                    }
                    
                    self.startChat(userData: self.arrUserList[index])
                }
                return
            }
            
            self.startChat(userData: self.arrUserList[index])
        }

        
        cell?.didScroll = { contentOffset in
            
            DispatchQueue.main.async {
                if contentOffset > 430  {
                    if self.headerBGView.alpha == 0 {
                        UIView.animate(withDuration: 0.3) {
                            self.headerBGView.alpha = 1
                            self.lblLogosHeader.textColor = .black
                            self.btnFilter.tintColor = .black
                            self.btnVisibility.tintColor = .black
                        }
                    }
                } else {
                    if self.headerBGView.alpha == 1 {
                        UIView.animate(withDuration: 0.3) {
                            self.headerBGView.alpha = 0
                            self.lblLogosHeader.textColor = .white
                            self.btnFilter.tintColor = .white
                            self.btnVisibility.tintColor = .white
                        }
                    }
                }
            }
        }
        
        func buttonEnable(_ value: Bool) {
            cell?.btnLike.isEnabled = value
            cell?.btnComment.isEnabled = value
            cell?.btnCancel.isEnabled = value
        }
        
        return cell ?? ProfileOverlayView()
    }
    
    func kolodaNumberOfCards(_ koloda: Koloda.KolodaView) -> Int {
        let cardCount = self.arrUserList.count

        if cardCount > 0 && cardCount - koloda.currentCardIndex <= 2 && currentPage < last_page{
            currentPage += 1
            apiCall_userList(page: currentPage)
        }
        
        return self.arrUserList.count
    }
}


extension HomeVC: KolodaViewDelegate, UIScrollViewDelegate {
    
    func kolodaDidRunOutOfCards(_ koloda: KolodaView) { koloda.reloadData() }
    
    func koloda(_ koloda: KolodaView, shouldSwipeCardAt index: Int, in direction: SwipeResultDirection) -> Bool {
        true
    }

    func koloda(_ koloda: KolodaView, shouldDragCardAt index: Int) -> Bool {
        false
    }
    
    func kolodaShouldApplyAppearAnimation(_ koloda: KolodaView) -> Bool {
        false
    }
}




//extension Dictionary {
//    func replaceNulls(with replacement: Any) -> [String: Any] {
//        var result: [String: Any] = [:]
//        
//        for (key, value) in self {
//            if let key = key as? String {
//                if value is NSNull {
//                    result[key] = replacement
//                } else if let dict = value as? [String: Any] {
//                    result[key] = dict.replaceNulls(with: replacement)
//                } else if let array = value as? [Any] {
//                    result[key] = array.map { item -> Any in
//                        if item is NSNull {
//                            return replacement
//                        } else if let dict = item as? [String: Any] {
//                            return dict.replaceNulls(with: replacement)
//                        }
//                        return item
//                    }
//                } else {
//                    result[key] = value
//                }
//            }
//        }
//        
//        return result
//    }
//}
